package com.dnb.experienceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExperienceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
